﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Nazvhi_and_The_Grimiore_Demo.Objects
{
    public class Obstacles:GameObject
    {
        public String ObstacleType { get; set; }

        public Obstacles()
            : base()
        {
            ObstacleType = null;
        }
        public void LoadContent(ContentManager content, string modelName)
        {
            Model = content.Load<Model>(modelName);
        }
    }
}
