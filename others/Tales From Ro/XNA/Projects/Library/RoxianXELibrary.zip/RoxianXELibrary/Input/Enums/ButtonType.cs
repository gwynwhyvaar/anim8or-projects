﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoxianXELibrary.Input.Enums
{
    public enum ButtonType { A, B, Back, LeftShoulder, LeftStick, RightShoulder, RightStick, Start, X, Y }
}
