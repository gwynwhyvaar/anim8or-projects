﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;

namespace RoxianXELibrary.Input.Interfaces
{
    public interface IInputHandler
    {
        KeyBoardhandler KeyboardState { get; }

        GamePadState[] GamePads { get; }

        ButtonHandler ButtonHandler { get; }

#if !XBOX360
        MouseState MouseState { get; }
        MouseState PreviousMouseState { get; }
#endif
    }
}
