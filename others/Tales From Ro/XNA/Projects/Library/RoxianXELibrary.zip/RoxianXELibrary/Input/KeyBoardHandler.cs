﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;

namespace RoxianXELibrary.Input
{
    public class KeyBoardhandler
    {
        private KeyboardState prevKeyBoardState;
        private KeyboardState keyBoardState;

        public KeyBoardhandler()
        {
            prevKeyBoardState = Keyboard.GetState();
        }
        public bool IsKeyDown(Keys key)
        {
            return (keyBoardState.IsKeyDown(key));
        }
        public bool IsHoldingKey(Keys key)
        {
            return (keyBoardState.IsKeyDown(key) && prevKeyBoardState.IsKeyDown(key));
        }
        public bool WasKeyPressed(Keys key)
        {
            return (keyBoardState.IsKeyDown(key) && prevKeyBoardState.IsKeyUp(key));
        }
        public bool HasReleasedKeys(Keys key)
        {
            return (keyBoardState.IsKeyUp(key) && prevKeyBoardState.IsKeyDown(key));
        }
        public void Update()
        {
            prevKeyBoardState = keyBoardState;

            keyBoardState = Keyboard.GetState();
        }
    }
}
