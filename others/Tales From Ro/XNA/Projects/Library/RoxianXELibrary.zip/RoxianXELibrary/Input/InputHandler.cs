using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using RoxianXELibrary.Input.Interfaces;
using RoxianXELibrary.Input.Enums;


namespace RoxianXELibrary.Input
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    /// 
    public class InputHandler : Microsoft.Xna.Framework.GameComponent,IInputHandler
    {
        public ButtonType ButtonType;

        //private KeyboardState keyboardState;

        private KeyBoardhandler keyboard;
        private ButtonHandler gamePadHandler = new ButtonHandler();

        private GamePadState[] gamePads = new GamePadState[4];

#if !XBOX360
        private MouseState mouseState;
        private MouseState prevMouseState;
#endif
        public InputHandler(Game game)
            : base(game)
        {
           game.Services.AddService(typeof(IInputHandler), this);

           keyboard = new KeyBoardhandler();

           gamePads[0] = GamePad.GetState(PlayerIndex.One);
           gamePads[1] = GamePad.GetState(PlayerIndex.Two);
           gamePads[2] = GamePad.GetState(PlayerIndex.Three);
           gamePads[3] = GamePad.GetState(PlayerIndex.Four);

#if !XBOX360
           Game.IsMouseVisible = true;
           prevMouseState = Mouse.GetState();
#endif
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here

            base.Initialize();
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            keyboard.Update();

            gamePadHandler.Update();

            if (keyboard.IsKeyDown(Keys.Escape))
            {
                Game.Exit();
            }
            if (gamePadHandler.WasButtonPressed(0, ButtonType.Back))
            {
                Game.Exit();
            }
#if !XBOX360
            prevMouseState = mouseState;
            mouseState = Mouse.GetState();
#endif
            //gamePads[0] = GamePad.GetState(PlayerIndex.One);
            //gamePads[1] = GamePad.GetState(PlayerIndex.Two);
            //gamePads[2] = GamePad.GetState(PlayerIndex.Three);
            //gamePads[3] = GamePad.GetState(PlayerIndex.Four);

            //if (gamePads[0].Buttons.Back == ButtonState.Pressed)
            //{
            //    Game.Exit();
            //}

            //keyboardState = Keyboard.GetState();
            //if (keyboardState.IsKeyDown(Keys.Escape))
            //{
            //    Game.Exit();
            //}
            base.Update(gameTime);
        }
        
        //#region IInputHandler Members

        //public KeyboardState KeyboardState
        //{
        //    get { return (keyboardState); }
        //}

        //#endregion

        #region IInputHandler Members


        public GamePadState[] GamePads
        {
            get { return (gamePads); }
        }

        #endregion

        #region IInputHandler Members

#if !XBOX360
        public MouseState MouseState
        {
            get { return (mouseState); }
        }

        public MouseState PreviousMouseState
        {
            get { return (prevMouseState); }
        }
#endif
        #endregion

        #region IInputHandler Members

        public ButtonHandler ButtonHandler
        {
            get { return (gamePadHandler); }
        }

        #endregion

        #region IInputHandler Members

        public KeyBoardhandler KeyboardState
        {
            get { return (keyboard); }
        }

        #endregion
    }
}