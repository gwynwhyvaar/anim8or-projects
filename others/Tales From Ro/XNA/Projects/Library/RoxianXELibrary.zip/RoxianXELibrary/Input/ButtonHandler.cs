﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using RoxianXELibrary.Input.Enums;

namespace RoxianXELibrary.Input
{
    public class ButtonHandler
    {
        private GamePadState[] prevGamePadsState = new GamePadState[4];
        private GamePadState[] gamePadsState = new GamePadState[4];

        public ButtonHandler()
        {
            prevGamePadsState[0] = GamePad.GetState(PlayerIndex.One);
            prevGamePadsState[1] = GamePad.GetState(PlayerIndex.Two);
            prevGamePadsState[2] = GamePad.GetState(PlayerIndex.Three);
            prevGamePadsState[3] = GamePad.GetState(PlayerIndex.Four);
        }
        public void Update()
        {
            prevGamePadsState[0] = gamePadsState[0];
            prevGamePadsState[1] = gamePadsState[1];
            prevGamePadsState[2] = gamePadsState[2];
            prevGamePadsState[3] = gamePadsState[3];

            //we get a new gampad state
            gamePadsState[0] = GamePad.GetState(PlayerIndex.One);
            gamePadsState[1] = GamePad.GetState(PlayerIndex.Two);
            gamePadsState[2] = GamePad.GetState(PlayerIndex.Three);
            gamePadsState[3] = GamePad.GetState(PlayerIndex.Four);
        }
        public bool WasButtonPressed(int playerIndex, ButtonType button)
        {
            int pi = playerIndex;

            switch (button)
            {
                case ButtonType.A:
                    {
                        return (gamePadsState[pi].Buttons.A == ButtonState.Pressed && prevGamePadsState[pi].Buttons.A == ButtonState.Released);
                    }
                case ButtonType.B:
                    {
                        return (gamePadsState[pi].Buttons.B == ButtonState.Pressed && prevGamePadsState[pi].Buttons.B == ButtonState.Released);
                    }
                case ButtonType.Back:
                    {
                        return (gamePadsState[pi].Buttons.Back == ButtonState.Pressed && prevGamePadsState[pi].Buttons.Back == ButtonState.Released);
                    }
                case ButtonType.LeftShoulder:
                    {
                        return (gamePadsState[pi].Buttons.LeftShoulder == ButtonState.Pressed && prevGamePadsState[pi].Buttons.LeftShoulder == ButtonState.Released);
                    }
                case ButtonType.LeftStick:
                    {
                        return (gamePadsState[pi].Buttons.LeftStick == ButtonState.Pressed && prevGamePadsState[pi].Buttons.LeftStick == ButtonState.Released);
                    }
                case ButtonType.RightShoulder:
                    {
                        return (gamePadsState[pi].Buttons.RightShoulder == ButtonState.Pressed && prevGamePadsState[pi].Buttons.RightShoulder == ButtonState.Released);
                    }
                case ButtonType.RightStick:
                    {
                        return (gamePadsState[pi].Buttons.RightStick == ButtonState.Pressed && prevGamePadsState[pi].Buttons.RightStick == ButtonState.Released);
                    }
                case ButtonType.Start:
                    {
                        return (gamePadsState[pi].Buttons.Start == ButtonState.Pressed && prevGamePadsState[pi].Buttons.Start == ButtonState.Released);
                    }
                case ButtonType.X:
                    {
                        return (gamePadsState[pi].Buttons.X == ButtonState.Pressed && prevGamePadsState[pi].Buttons.Start == ButtonState.Released);
                    }
                case ButtonType.Y:
                    {
                        return (gamePadsState[pi].Buttons.Y == ButtonState.Pressed && prevGamePadsState[pi].Buttons.Y == ButtonState.Released);
                    }
                default:
                    throw (new ArgumentException("no button type specified"));
            }
        }
    }
        
}
