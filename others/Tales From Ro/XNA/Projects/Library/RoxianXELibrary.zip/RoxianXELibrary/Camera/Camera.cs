using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using RoxianXELibrary.Input.Interfaces;
using RoxianXELibrary.Input;


namespace RoxianXELibrary.Camera
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Camera : Microsoft.Xna.Framework.GameComponent
    {
        protected int playerIndex = 0;

        protected Vector3 movement = Vector3.Zero;

        private const float moveRate = 120.0f;

        private float cameraYaw = 0.0f;
        private float cameraPitch = 0.0f;

        private const float spinRate = 2.0f;

        protected IInputHandler input;
        private GraphicsDeviceManager graphics;

        private Matrix projection;
        private Matrix view;

        public Matrix View { get { return view; } }
        public Matrix Projection { get { return projection; } }

        private Vector3 cameraPosition = new Vector3(0.0f, 0.0f, 3.0f);
        private Vector3 cameraTarget = Vector3.Zero;
        private Vector3 cameraUpVector = Vector3.Up;
        private Vector3 cameraReference = new Vector3(0.0f, 0.0f, -1.0f);

        private Viewport? viewPort;

        public Vector3 CameraPosition { get { return cameraPosition; } }
        public Vector3 CameraTarget { get { return cameraTarget; } }
        public Vector3 CameraUpVector { get { return CameraUpVector; } }

        public PlayerIndex PlayerIndexes
        {
            get { return ((PlayerIndex)playerIndex); }
            set { playerIndex = (int)value; }
        }
        public Vector3 Position
        {
            get
            {
                return (cameraPosition);
            }
            set { cameraPosition = value; }
        }
        public Vector3 Orientation
        {
            get { return (cameraReference); }
            set { cameraReference = value; }
        }
        public Vector3 Target
        {
            get { return (cameraTarget); }
            set { cameraTarget = value; }
        }
        public Viewport ViewPort
        {
            get
            {
                if (viewPort == null)
                {
                    viewPort = graphics.GraphicsDevice.Viewport;
                }
                return ((Viewport)viewPort);
            }
            set
            {
                viewPort = value;
                InitializeCamera();
            }
        }
        public Camera(Game game)
            : base(game)
        {
            graphics = (GraphicsDeviceManager)Game.Services.GetService(typeof(IGraphicsDeviceManager));
            input = (IInputHandler)game.Services.GetService(typeof(IInputHandler));
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here

            base.Initialize();
            InitializeCamera();
        }
        private void InitializeCamera()
        {
            float aspectRatio = (float)graphics.GraphicsDevice.Viewport.Width / (float)graphics.GraphicsDevice.Viewport.Height;
            Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, aspectRatio, 1.0f, 10000.0f, out projection);
            Matrix.CreateLookAt(ref cameraPosition, ref cameraTarget, ref cameraUpVector, out view);
        }
        
        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            float timeDelta = (float)gameTime.ElapsedGameTime.TotalSeconds;
#if !XBOX360
            if ((input.PreviousMouseState.X > input.MouseState.X) && (input.MouseState.LeftButton == ButtonState.Pressed))
            {
                cameraYaw += (spinRate * timeDelta);
            }
            else if ((input.PreviousMouseState.X < input.MouseState.X) && (input.MouseState.LeftButton == ButtonState.Pressed))
            {
                cameraYaw -= (spinRate * timeDelta);
            }

            if ((input.PreviousMouseState.Y > input.MouseState.Y) && (input.MouseState.LeftButton == ButtonState.Pressed))
            {
                cameraPitch += (spinRate * timeDelta);
            }
            else if ((input.PreviousMouseState.Y < input.MouseState.Y) && (input.MouseState.LeftButton == ButtonState.Pressed))
            {
                cameraPitch -= (spinRate * timeDelta);
            }
            if (cameraPitch > 89)
            {
                cameraPitch = 89;
            }
            if (cameraPitch < -89)
            { 
                cameraPitch = -89; 
            }
#endif
            

            if (input.KeyboardState.IsKeyDown(Keys.Down) || (input.GamePads[playerIndex].ThumbSticks.Right.Y < 0))
            {
                cameraPitch -= (spinRate * timeDelta);
            }
            if (input.KeyboardState.IsKeyDown(Keys.Up) || (input.GamePads[playerIndex].ThumbSticks.Right.Y > 0))
            {
                cameraPitch += (spinRate * timeDelta);
            }
            if (input.KeyboardState.IsKeyDown(Keys.Left)||(input.GamePads[playerIndex].ThumbSticks.Right.X<0))
            {
                cameraYaw += (spinRate*timeDelta);
            }
            if (input.KeyboardState.IsKeyDown(Keys.Right)||(input.GamePads[playerIndex].ThumbSticks.Right.X>0))
            {
                cameraYaw -= (spinRate*timeDelta);
            }
            if (cameraYaw > 360)
            {
                cameraYaw -= 360;
            }
            else if (cameraYaw < 0)
            {
                cameraYaw += 360;
            }

            movement *= (moveRate * timeDelta);

            Matrix rotationMatrix;
            Matrix.CreateRotationY(MathHelper.ToRadians(cameraYaw), out rotationMatrix);

            //uncomment this to make first - person camera 'fly'
            //rotationMatrix = Matrix.CreateRotationX(MathHelper.ToRadians(cameraPitch)) * rotationMatrix;
            //

            if (movement != Vector3.Zero)
            {
                Vector3.Transform(ref movement, ref rotationMatrix, out movement);
                cameraPosition += movement;
            }

            //comment this if one above is un-commented
            rotationMatrix = Matrix.CreateRotationX(MathHelper.ToRadians(cameraPitch)) * rotationMatrix;

            //next we create a vector pointing in the direction the camera is facing
            Vector3 transformedReference;
            Vector3.Transform(ref cameraReference, ref rotationMatrix, out transformedReference);

            //let's calculate the position the camera is looking at
            Vector3.Add(ref cameraPosition, ref transformedReference, out cameraTarget);

            Matrix.CreateLookAt(ref cameraPosition, ref cameraReference, ref cameraUpVector, out view);
            base.Update(gameTime);
        }
    }
}