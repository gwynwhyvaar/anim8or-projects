﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using RoxianXELibrary.Input.Interfaces;
using Microsoft.Xna.Framework.Input;

namespace RoxianXELibrary.Camera
{
    public class FirstPersonCamera:Camera
    {
        public FirstPersonCamera(Game game) : base(game) { }

        public override void Update(GameTime gameTime)
        {
            movement = Vector3.Zero;

            if (input.KeyboardState.IsKeyDown(Keys.A) || (input.GamePads[playerIndex].ThumbSticks.Left.X < 0))
            {
                movement.X--;
            }
            if (input.KeyboardState.IsKeyDown(Keys.D) || (input.GamePads[playerIndex].ThumbSticks.Left.X > 0))
            {
                movement.X++;
            }
            if (input.KeyboardState.IsKeyDown(Keys.S) || (input.GamePads[playerIndex].ThumbSticks.Left.Y < 0))
            {
                movement.Z++;
            }
            if (input.KeyboardState.IsKeyDown(Keys.W) || (input.GamePads[playerIndex].ThumbSticks.Left.Y > 0))
            {
                movement.Z--;
            }
            if (movement.LengthSquared() != 0)
            {
                movement.Normalize();
            }
            base.Update(gameTime);
        }
    }
}
