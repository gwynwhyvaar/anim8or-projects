using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;


namespace RoxianXELibrary.FPS
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Fps : Microsoft.Xna.Framework.DrawableGameComponent
    {
        private float fps;
        private float updateInterval = 1.0f;
        private float timeSinceLastUpdate = 1.0f;
        private float framecount = 0;

        public Fps(Game game)
            : this(game,false,false,game.TargetElapsedTime)
        {
            // TODO: Construct any child components here
        }
        /// <summary>
        /// OVERLOADED CONSTRUCTOR, SO WE CAN DECIDE NOT TO PASS A TARGET ELAPSED TIME - IT HAS A DEFAULT VALUE NOW
        /// </summary>
        /// <param name="game"></param>
        /// <param name="synchWithVerticalRetrace"></param>
        /// <param name="isFixedTimeStep"></param>
        public Fps(Game game, bool synchWithVerticalRetrace, bool isFixedTimeStep) : this(game, synchWithVerticalRetrace, isFixedTimeStep, game.TargetElapsedTime) { }
        public Fps(Game game, bool synchWithVerticalRetrace, bool isFixedTimeStep, TimeSpan targetElapsedTime)
            : base(game)
        {
            GraphicsDeviceManager graphics = (GraphicsDeviceManager)game.Services.GetService(typeof(IGraphicsDeviceManager));
            graphics.SynchronizeWithVerticalRetrace = synchWithVerticalRetrace;

            Game.IsFixedTimeStep = isFixedTimeStep;
            Game.TargetElapsedTime = targetElapsedTime;
        }
        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here

            base.Initialize();
        }
        public override void Draw(GameTime gameTime)
        {
            float elapsed = (float)gameTime.ElapsedRealTime.TotalSeconds;
            framecount++;
            timeSinceLastUpdate += elapsed;

            if (timeSinceLastUpdate > updateInterval)
            {
                fps = framecount / timeSinceLastUpdate;
#if XBOX360
                System.Diagnostics.Debug.WriteLine("FPS :" + fps.ToString());
#else
                Game.Window.Title = "FPS :" + fps.ToString();
#endif
                framecount = 0;
                timeSinceLastUpdate -= updateInterval;
            }
            base.Draw(gameTime); 
        }
        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here

            base.Update(gameTime);
        }
    }
}