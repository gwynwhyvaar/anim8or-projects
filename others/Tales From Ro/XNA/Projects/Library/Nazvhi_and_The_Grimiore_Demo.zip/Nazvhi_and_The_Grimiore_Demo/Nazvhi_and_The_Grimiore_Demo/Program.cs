using System;

namespace Nazvhi_and_The_Grimiore_Demo
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            using (Nazvhi_and_The_Grimoire_Demo_Game_Class game = new Nazvhi_and_The_Grimoire_Demo_Game_Class())
            {
                game.Run();
            }
        }
    }
}

